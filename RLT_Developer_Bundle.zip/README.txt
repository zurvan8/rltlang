RLT Developer Bundle
====================
This package contains everything needed to begin using and contributing to the Recursive Language of Transformation (RLT).

Included:
---------
- Clause grammar and execution engine
- Dual-language teaching guide
- Ethical charter
- Primer for coders and symbolic practitioners
- Teaching primer and symbolic index
- Complete language roadmap and installation plan

Getting Started:
----------------
1. Read primer.txt (core/primer.txt)
2. Explore clause types (docs/clause_sheet.json)
3. Load grammar_engine.py and test symbolic clause transformations
4. Use charter.json to review ethical constraints
5. Follow installation roadmap for agent deployment

License:
--------
All components are open-source under symbolic integrity guidelines.
